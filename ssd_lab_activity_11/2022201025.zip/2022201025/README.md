# SSD Lab Activity 11

## Question 1
- Dropping the last 6 columns using list splicing

## Question 2
- Dropping the rows with %change <= 3% using filter and lambda

## Question 3
- Calculating Individual sums of open, high, low columns using map, lambda and finally, calculating the averages by zipping(transposing the above list).
- Writing to file is done using print(value,file=f).

## Question 4
- Taking user input with input() function and then comparing the first letter of first column of each row in our csv_data.

## Question 5
- Writing the output in question 4 into file using file_handling(open in "w" mode)